/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package edu.unicauca.ttm.ejemploclientesocket;

import java.io.DataInputStream;
import java.io.InputStream;
import java.net.Socket;

/**
 *
 * @author cfigmart
 */
public class EjemploClienteSocket {
    private String ip = "localhost";
    private int puerto = 5000; 

    public void iniciarCliente() {
        try {
            //Se crea el socket en el puerto 5000
           
 
            System.out.println("Creando cliente y conectando al servidor en la IP "+ip+":"+puerto);
            Socket skCliente = new Socket(ip, puerto);
            InputStream aux = skCliente.getInputStream();
            //se asocia el flujo de datos 
            DataInputStream flujo = new DataInputStream(aux);
            //Se crea el flujo de lectura secuencial
            System.out.println(flujo.readUTF());
            skCliente.close();//Se  cierra el socket.
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public static void main(String[] args) {
        EjemploClienteSocket cliente = new EjemploClienteSocket(); 
        cliente.iniciarCliente();
    }
}
