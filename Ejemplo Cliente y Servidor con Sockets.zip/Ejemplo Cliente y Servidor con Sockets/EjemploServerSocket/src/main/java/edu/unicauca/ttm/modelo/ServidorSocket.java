/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.unicauca.ttm.modelo;

import edu.unicauca.ttm.control.ControlServerSocket;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cfigmart
 */
public class ServidorSocket extends Thread{
    private String nombre; 
    private int num_clientes; 
    private int puerto; 
    private boolean enEjecucion; 
    private final ControlServerSocket control;
    private ServerSocket skServidor;
    

    public ServidorSocket(String nombre, int num_clientes, int puerto, ControlServerSocket control) {
        this.nombre = nombre;
        this.num_clientes = num_clientes;
        this.puerto = puerto;
        this.control = control; 
    }
    
     public void iniciarServidor() { 
        enEjecucion = true; 
        this.start();
    }
     
     public void detenerServidor(){
        try {
            enEjecucion = false;
            if(skServidor!=null){
                skServidor.close(); 
                skServidor = null;
            }
        } catch (IOException ex) {
            Logger.getLogger(ServidorSocket.class.getName()).log(Level.SEVERE, null, ex);
        }
     }

   
        @Override
    public void run() {
         try {
            //permite esperar conexiones en el puerto 5000
            skServidor = new ServerSocket(puerto);
            System.out.println("Escucho en el puerto " + puerto);
            //Atendera maximo 4 clientes pero se puede configurar
            //Para atender muchos más, por ejemplo si se coloca
            //Un while(true) en lugar del for
            for (int numCli = 0; numCli < num_clientes && enEjecucion; numCli++) {
                //El socket servidor acepta la conecci'on
                System.out.println("Esperando al cliente "+numCli+" ...");
                control.agregarMensajesServidor("Esperando al cliente "+numCli+" ...");
                Socket skCliente = skServidor.accept();
                System.out.println("Sirvo al cliente " + numCli);
                control.agregarMensajesServidor("Se conecta el cliente "+numCli);
                OutputStream aux = skCliente.getOutputStream();
                DataOutputStream flujo = new DataOutputStream(aux);
                //Se envia un mensaje al cliente que se conecta
                flujo.writeUTF(nombre+" -> Hola cliente " + numCli);
                //se cierra el flujo
                skCliente.close();
            }
            System.out.println("Capacidad de clientes excedido");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
}
