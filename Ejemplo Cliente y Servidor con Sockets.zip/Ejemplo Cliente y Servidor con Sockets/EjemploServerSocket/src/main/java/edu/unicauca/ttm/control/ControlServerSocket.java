/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package edu.unicauca.ttm.control;

import edu.unicauca.ttm.modelo.ServidorSocket;
import edu.unicauca.ttm.vista.VistaServidor;

/**
 *
 * @author cfigmart
 */
public class ControlServerSocket extends Thread{

    VistaServidor vistaServidor; 


    private ServidorSocket servidor; 

    public ControlServerSocket() {
       
        vistaServidor = new VistaServidor(this); 
        
    }

    public void detenerServidor(){
        servidor.detenerServidor();
        servidor = null;  
        vistaServidor.habilitarBtIniciar();
    }

    public static void main(String[] arg) {
        ControlServerSocket servidor = new ControlServerSocket();
        servidor.mostrarVista(); 
    }

    private void mostrarVista() {
        vistaServidor.setVisible(true); 
    }

    public void iniciarServidor(String nombreServer, int puerto, int num_clientes) {
        if(servidor == null){
            servidor = new ServidorSocket(nombreServer, num_clientes, puerto, this);
            servidor.iniciarServidor();
            vistaServidor.habilitarBtDetener();
        }
            
            
        else 
           vistaServidor.mostrarError("El servidor ya está en ejecución");
    }

    public void agregarMensajesServidor(String string) {
        vistaServidor.agregarMensajesServidor(string);
    }

}
