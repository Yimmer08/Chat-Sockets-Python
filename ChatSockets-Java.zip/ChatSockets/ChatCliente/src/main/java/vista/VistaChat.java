package vista;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle;
import javax.swing.WindowConstants;
import control.Cliente;
import java.awt.Color;
import java.io.File;
import java.util.Date;

public class VistaChat extends javax.swing.JFrame {

Date fecha = new Date();

/////////////////////
Cliente cliente;
private JButton btBorrar;
private JButton btEnviar;
private JComboBox jComboBox1;
private JPanel jPanel1;
private JScrollPane jScrollPane2;
private JScrollPane spPrinciapal;
private JTextArea taEnviar;
private JTextArea taPrincipal;
public VistaChat(Cliente cliente) {
this.cliente = cliente;
initComponents();
}
//Actualiza los mensajes que el usuario envia y recibe
public void actualizarMensajes(String mensaje){
taPrincipal.append("\n"+mensaje);
}
private void initComponents() {
jComboBox1 = new JComboBox();
jPanel1 = new JPanel();
spPrinciapal = new JScrollPane();
taPrincipal = new JTextArea();
jScrollPane2 = new JScrollPane();
taEnviar = new JTextArea();
btEnviar = new JButton();
btBorrar = new JButton();
jComboBox1.setModel(new DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item4" }));
setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
spPrinciapal.setViewport(null);
taPrincipal.setColumns(20);
taPrincipal.setEditable(false);
taPrincipal.setRows(5);
spPrinciapal.setViewportView(taPrincipal);
taEnviar.setColumns(20);
taEnviar.setRows(5);
jScrollPane2.setViewportView(taEnviar);
btEnviar.setText("Enviar");
btEnviar.setBackground(Color.GREEN);

btEnviar.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
btEnviarActionPerformed(evt);
}
});
btBorrar.setText("Borrar");
btBorrar.setBackground(Color.red);
btBorrar.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
btBorrarActionPerformed(evt);
}
});
GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
jPanel1.setLayout(jPanel1Layout);
jPanel1Layout.setHorizontalGroup(
jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
.addGroup(jPanel1Layout.createSequentialGroup()
.addContainerGap()
.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
.addComponent(spPrinciapal, GroupLayout.DEFAULT_SIZE, 363, Short.MAX_VALUE)
.addGroup(jPanel1Layout.createSequentialGroup()
.addComponent(jScrollPane2, GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE)
.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
.addComponent(btBorrar)
.addComponent(btEnviar))))
.addContainerGap())
);
jPanel1Layout.setVerticalGroup(
jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
.addGroup(jPanel1Layout.createSequentialGroup()
.addContainerGap()
.addComponent(spPrinciapal, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
.addGroup(jPanel1Layout.createSequentialGroup()
.addComponent(btEnviar)
.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
.addComponent(btBorrar))
.addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE))
.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
);
GroupLayout layout = new GroupLayout(getContentPane());
getContentPane().setLayout(layout);
layout.setHorizontalGroup(
layout.createParallelGroup(GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addContainerGap()
.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
.addContainerGap())
);
layout.setVerticalGroup(
layout.createParallelGroup(GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addContainerGap()

.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
GroupLayout.PREFERRED_SIZE)

.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
);
pack();
}
//Borra el texto que esta en la area de texto a enviar.
private void btBorrarActionPerformed(java.awt.event.ActionEvent evt) {
taEnviar.setText("");

}
//Envia el texto que el cliente escribe
private void btEnviarActionPerformed(java.awt.event.ActionEvent evt) {
cliente.escribirMensaje(taEnviar.getText());
actualizarMensajes(cliente.nombre+" dice> "+taEnviar.getText()+ "\n" + fecha );
taEnviar.setText("");
}
}