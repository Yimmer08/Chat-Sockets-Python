package control;
import java.io.*;
import java.net.*;
import vista.InicioSesion1;
import vista.VistaChat;
public class Cliente{
        protected Socket socketCliente;
        protected PrintStream salida;
        public BufferedReader entrada;
        public String IP="localhost";
        public String nombre="anonimo";
        private InicioSesion1 inicioS;
        private VistaChat vistaChat;

        public Cliente(){}
        public void iniciar(){
        //Mostrar la ventana de inicio de sesion
            inicioS = new InicioSesion1(this);
            inicioS.setVisible(true);
        }   
        public boolean conectarse(){
            boolean retorno=false;
            try {
                    //Abre el socket en el mismo puerto que el servidor
                socketCliente = new Socket(IP,5000);
                salida = new PrintStream(
                socketCliente.getOutputStream()); //agrega datos a una corriente de flujo
                entrada = new BufferedReader(
                    new InputStreamReader(
                        socketCliente.getInputStream())); //leer texto de una secuencia de entrada 

            //si la conexion es exitosa entonces:
            //Oculta la ventana de inicio de sesion
                inicioS.setVisible(false);
                //Muestra la vista principal del chat
                vistaChat = new VistaChat(this);
                   vistaChat.setVisible(true);
                //Inicia la clase que recibe mensajes
                new Lector(this);
                //Envia el nombre ingresado al servidor
                salida.println(nombre);
                retorno=true;
                } catch (UnknownHostException ex) {
ex.printStackTrace();
} catch (IOException ex) {
ex.printStackTrace();
}
return retorno;
}
//Este metodo permite enviar mensajes a un cliente
public void escribirMensaje(String mensaje){
mostar(mensaje);
salida.println(mensaje);
}
//Este metodo actualiza los mensajes que se muestran
//en la ventana del chat
public void mostar(String mensaje){
vistaChat.actualizarMensajes(mensaje);
}
public static void main(String[] args)
throws IOException, ConnectException{
Cliente cliente = new Cliente();
cliente.iniciar();//Crea al cliente
}
}